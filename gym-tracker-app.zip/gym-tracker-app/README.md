# Gym Tracker

Gym-Tracker fürs Handy: Sätze loggen, Vorlagen, Trainingsvergleich, Fortschritt, Erholung und Makros.
Die App ist eine einzelne Web-Seite (`www/index.html`), die mit [Capacitor](https://capacitorjs.com) in eine Android-App verpackt wird.

## APK über GitHub bauen (ohne Android Studio)

1. Auf GitHub ein neues Repository anlegen (privat reicht).
2. Den Inhalt dieses Ordners hochladen (ZIP entpacken, dann per „Add file → Upload files“ oder per `git push`). Wichtig: Der Ordner `.github` muss mit hoch.
3. Auf GitHub den Tab **Actions** öffnen. Der Workflow „Android APK bauen“ startet bei jedem Push, oder manuell über „Run workflow“.
4. Nach etwa 5 bis 10 Minuten im fertigen Lauf unter **Artifacts** die Datei `gym-tracker-debug-apk` herunterladen und entpacken.
5. `app-debug.apk` aufs Handy kopieren und installieren (Android fragt einmal nach „Installation aus unbekannten Quellen“).

## Lokal bauen

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android      # öffnet Android Studio, dort Run drücken
```

## Daten

Alle Daten liegen lokal im Speicher der App auf dem Handy. Wird die App deinstalliert oder ihr Speicher gelöscht, sind sie weg.

## Anpassen

- Alles an der App steht in `www/index.html` (Übungen, Vorlagen und Ziele oben im Skript unter `LIB` und `defaultState`).
- App-Name und Paketname stehen in `capacitor.config.json`. Den Paketnamen (`appId`) vor einer Veröffentlichung im Play Store ändern.
- Das Beispielprofil mit Demodaten lässt sich in der App über „Entfernen“ im Banner löschen. Zum Abschalten die Zeile `else{state=defaultState();seedDemo(state)}` in `www/index.html` zu `else{state=defaultState()}` ändern.
- Für den Play Store braucht es eine signierte Release-Version (`assembleRelease` plus Keystore). Der Workflow baut bewusst nur die Debug-APK.
