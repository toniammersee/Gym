# Gym Tracker

Gym-Tracker fürs Handy: Sätze loggen (mit Supersätzen, Notizen und Pausenzeit je Übung), Vorlagen, Wochenplan mit Erinnerung, Trainingsvergleich, Kalender, Fortschritt, Körpermaße, Erholung, Essen mit Makros, Wasser, Supplements, Lebensmittel-Datenbank, Barcode-Scan, Rechner, App-Icon und Daten-Export.

Die App ist eine Web-Seite (`www/index.html`), die mit [Capacitor](https://capacitorjs.com) in eine Android-App verpackt wird.

## APK über GitHub bauen (nur mit dem Handy)

1. Neues Repository auf GitHub anlegen.
2. Diese ZIP-Datei (`gym-tracker-app.zip`) in den Hauptordner des Repositorys hochladen.
3. Die Datei `android.yml` unter `.github/workflows/android.yml` im Repository anlegen (Inhalt einfügen). Sie gehört nicht in die ZIP.
4. Im Tab **Actions** läuft der Bau von selbst. Danach unter **Artifacts** die Datei `gym-tracker-debug-apk` herunterladen, entpacken und `gym-tracker.apk` installieren.

## Hinweise

- Alle Daten liegen lokal auf dem Handy. Über Einstellungen (Regler-Symbol oben rechts) kannst du ein Backup speichern und wieder einlesen.
- Erinnerungen und Barcode-Scan funktionieren nur in der installierten App. Die Produktsuche braucht Internet (Open Food Facts).
- Die Datei `android-res/` enthält das App-Icon. Der Workflow kopiert es in das Android-Projekt.
- Für den Play Store braucht es eine signierte Release-Version und einen eigenen Paketnamen in `capacitor.config.json`.
